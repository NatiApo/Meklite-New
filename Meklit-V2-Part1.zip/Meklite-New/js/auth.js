import { auth, db } from './firebase-config.js';
import { onAuthStateChanged, signInWithEmailAndPassword, sendPasswordResetEmail, signOut } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js';
import { doc, getDoc } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js';

const form = document.getElementById('loginForm');
const email = document.getElementById('email');
const password = document.getElementById('password');
const button = document.getElementById('loginButton');
const message = document.getElementById('message');
const forgot = document.getElementById('forgotButton');
const toggle = document.getElementById('togglePassword');
document.getElementById('year').textContent = new Date().getFullYear();
const dashboardURL = new URL('dashboard.html', window.location.href).href;
function showMessage(text, type = 'error') { message.hidden = false; message.textContent = text; message.className = `message ${type}`; }
function friendlyError(error) {
  switch(error.code) {
    case 'auth/invalid-email': return 'Enter a valid email address.';
    case 'auth/invalid-credential':
    case 'auth/wrong-password':
    case 'auth/user-not-found': return 'Email or password is incorrect.';
    case 'auth/too-many-requests': return 'Too many attempts. Please try again later.';
    case 'auth/network-request-failed': return 'Network error. Check your internet connection.';
    case 'auth/unauthorized-domain': return 'This website domain must be authorized in Firebase Authentication.';
    case 'permission-denied': return 'You do not have permission to access this account.';
    default: return 'Unable to continue. Check your Firebase setup and internet connection.';
  }
}
async function hasActiveRole(user) {
  const snap = await getDoc(doc(db, 'users', user.uid));
  const data = snap.data();
  return snap.exists() && data.active === true && ['admin','user'].includes(data.role);
}
let checking = false;
onAuthStateChanged(auth, async user => {
  if (!user || checking) return;
  checking = true;
  try {
    if (await hasActiveRole(user)) window.location.replace(dashboardURL);
    else { await signOut(auth); showMessage('Your account has not been authorized by the administrator.'); }
  } catch(error) { showMessage(friendlyError(error)); }
  finally { checking = false; }
});
form.addEventListener('submit', async event => {
  event.preventDefault();
  if (!email.value.trim() || !password.value) { showMessage('Please enter your email and password.'); return; }
  button.disabled = true; button.textContent = 'Signing in…'; message.hidden = true;
  try {
    const result = await signInWithEmailAndPassword(auth, email.value.trim(), password.value);
    if (await hasActiveRole(result.user)) window.location.replace(dashboardURL);
    else { await signOut(auth); showMessage('Your account is not authorized. Contact the administrator.'); }
  } catch(error) { showMessage(friendlyError(error)); }
  finally { button.disabled = false; button.textContent = 'Sign in →'; }
});
forgot.addEventListener('click', async () => {
  const address = email.value.trim();
  if (!address) { showMessage('Enter your email address first, then select Forgot password.'); email.focus(); return; }
  forgot.disabled = true;
  try {
    await sendPasswordResetEmail(auth, address);
    showMessage('If this email has an account, a password reset email will be sent. Check your inbox and spam folder.', 'success');
  } catch(error) { showMessage(friendlyError(error)); }
  finally { forgot.disabled = false; }
});
toggle.addEventListener('click', () => {
  const showing = password.type === 'password';
  password.type = showing ? 'text' : 'password';
  toggle.textContent = showing ? 'Hide' : 'Show';
  toggle.setAttribute('aria-label', showing ? 'Hide password' : 'Show password');
});
