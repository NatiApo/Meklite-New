import { auth, db } from './firebase-config.js';
import { onAuthStateChanged, signOut } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js';
import { doc, getDoc } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js';
const info = document.getElementById('accountInfo');
const role = document.getElementById('roleText');
const accessMessage = document.getElementById('accessMessage');
const loginURL = new URL('index.html', window.location.href).href;
const signOutButton = document.getElementById('signOutButton');
let verified = false;
function showError(text) { accessMessage.hidden = false; accessMessage.className = 'message error'; accessMessage.textContent = text; }
onAuthStateChanged(auth, async user => {
  if (!user) { window.location.replace(loginURL); return; }
  try {
    const snap = await getDoc(doc(db, 'users', user.uid));
    const profile = snap.data();
    if (!snap.exists() || profile.active !== true || !['admin','user'].includes(profile.role)) {
      await signOut(auth); window.location.replace(loginURL); return;
    }
    verified = true;
    info.textContent = `Signed in as ${user.email || 'authorized user'}`;
    role.textContent = profile.role === 'admin' ? 'Administrator' : 'Simple User';
  } catch(error) {
    info.textContent = 'Unable to verify access.';
    showError('Your permissions could not be verified. Check your connection and Firestore rules, then sign in again.');
    role.textContent = 'Unverified';
  }
});
signOutButton.addEventListener('click', async () => {
  signOutButton.disabled = true;
  try { await signOut(auth); window.location.replace(loginURL); }
  catch(error) { showError('Sign out failed. Please try again.'); signOutButton.disabled = false; }
});
