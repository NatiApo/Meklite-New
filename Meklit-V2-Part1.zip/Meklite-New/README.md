# Apostolic Church Youth Meklit V2

Part 1: Firebase email/password login, protected dashboard, and GitHub Pages frontend.

## Setup
1. Create Firebase Spark project and web app.
2. Enable Authentication > Email/Password and create your first user.
3. Create Firestore database and publish `firestore.rules` in Firebase Console.
4. In Firestore, create `users/{Firebase Authentication UID}` with `role` (string) = `admin`, `active` (boolean) = `true`.
5. Replace placeholders in `js/firebase-config.js` with your Firebase web config.
6. Add your GitHub Pages domain in Authentication > Settings > Authorized domains.
7. Publish GitHub Pages from the main branch, root folder.

Do not store member records or service account credentials in GitHub. The Firebase web config is public, but Firestore rules must restrict access.

Part 1 contains no candidate, contribution, reporting, or user-management workflows yet.
